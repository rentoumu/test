import {createRouter, createWebHashHistory} from 'vue-router'

export const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    {
      path: '/',
      name: 'Index',
      component: () => import('../views/Index.vue'),
      meta: {
        keepAlive: false,
      },
      children: [
        {
          path: 'first',
          name: 'FirstRouter',
          component: () => import('../views/First.vue'),
          meta: {
            keepAlive: true,
          },
          children: [
            {
              path: 'second',
              name: 'SecondRouter',
              component: () => import('../views/Second.vue'),
              meta: {
                keepAlive: false,
              },
            }
          ]
        }
      ]
    }
  ]
})