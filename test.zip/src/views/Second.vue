<template>
    <h1>Second Router View</h1>
    <md-editor v-model="ctx.content" @onUploadImg="upload_image"></md-editor>
</template>

<script setup lang="ts">
import MdEditor from 'md-editor-v3';
import 'md-editor-v3/lib/style.css';
import {reactive} from "vue";

const ctx = reactive({
    content: ''
})

const upload_image = async (files: FileList, callback: (urls: string[]) => void) => {
    console.log("upload files:", files)
    const res = await Promise.all(
        Array.from(files).map((file) => {
            return new Promise((rev, rej) => {
                // ...上传图片
                rev("https://test.com/image.png")
            });
        })
    );
    callback(res.map((item: any) => item));
}
</script>

<style scoped>

</style>