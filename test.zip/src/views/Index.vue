<template>
    <h1>Index Router</h1>
    <button @click="$router.push({name:'FirstRouter'})">跳转至second router</button>
    <router-view v-slot="{ Component }">
        <keep-alive>
            <component :is="Component" v-if="$route.meta.keepAlive"/>
        </keep-alive>
        <component :is="Component" v-if="!$route.meta.keepAlive"/>
    </router-view>
</template>

<script setup lang="ts">
</script>

<style scoped>

</style>